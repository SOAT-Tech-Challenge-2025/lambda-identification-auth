package tech.buildrun.lambda;

import com.amazonaws.services.lambda.runtime.Context;

import java.util.Map;

public interface CriarClienteLambdaInterface {

    String handleRequest(Map<String, Object> input, Context context);
}
